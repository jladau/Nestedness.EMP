package edu.ucsf.deprecated;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.math3.util.Precision;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import com.google.common.collect.Range;

import edu.ucsf.base.HashBasedTable4D;

/**
 * Class for implementing geospatial raster without temporal data.
 * @author jladau
 */

public class GeospatialRaster0 extends HashBasedTable4D<Integer,Integer,Integer,Integer>{
	
	/**Value for unset time**/
	public final LocalDate NULL_TIME=new LocalDate(9999,9,9);
	
	/**Value for unset vertical**/
	public final double NULL_VERT=Double.MAX_VALUE;
	
	/**Cell size in the latitude direction**/
	public double dLatResolution;
	
	/**Cell size in the longitude direction**/
	public double dLonResolution;
	
	/**Latitude range**/
	public Range<Double> rngLat;
	
	/**Longitude range**/
	public Range<Double> rngLon;
	
	/**Map from lower latitudes of cells to indices**/
	protected TreeMap<Double,Integer> mapLat;
	
	/**Map from lower longitudes of cells to indices**/
	protected TreeMap<Double,Integer> mapLon;
	
	/**Map from lower dates of cells to indices**/
	private TreeMap<LocalDate,Integer> mapDate;
	
	/**Map from lower vert bounds to indices**/
	private TreeMap<Double,Integer> mapVert;
	
	/**Number of rows of data in raster**/
	public int iRows;
	
	/**Number of columns of data in raster**/
	public int iCols;

	/**Current date to use**/
	protected LocalDate tim1 = NULL_TIME;
	
	/**Current date index**/
	private int iDateIndex;
	
	/**Current vertical value to use**/
	protected double dVert = NULL_VERT;
	
	/**Current vertical index**/
	private int iVertIndex;

	/**List of all loaded coordinates**/
	private ArrayList<GeoCoordinate> lstCoords;

	/**Name of variable in raster**/
	public String sVarName = null;
	
	/**Units of variable in raster**/
	public String sVarUnits = null;
	
	public GeospatialRaster0(){
	}
	
	public GeospatialRaster0(double dLatResolution, double dLonResolution, Range<Double> rngLat, Range<Double> rngLon, String sVarName, String sVarUnits){
		initialize(dLatResolution, dLonResolution, rngLat, rngLon, sVarName, sVarUnits);
	}
	
	/**
	 * Clears all entries
	 */
	public void clearAll(){
		super.initialize();
		initialize(dLatResolution, dLonResolution, rngLat, rngLon, sVarName, sVarUnits);
	}
	
	/**
	 * Converts geographic coordinates to index coordinates.
	 * @param gco1 Geographic coordinates for conversion.
	 * @return Index coordinates for geographic coordinates.
	 */
	private IndexCoordinate convertGeoCoordinateToIndexCoordinate(GeoCoordinate gco1){

		//iLat = latitude index
		//iLon = longitude index
		//iTime = time index
		//iVert = vert index
		
		int iLat;
		int iLon;
		int iTime;
		int iVert;
		
		iLat = mapLat.get(mapLat.floorKey(gco1.dLat));
		iLon = mapLon.get(mapLon.floorKey(gco1.dLon));
		iTime = mapDate.get(this.findNearestTimeKey());
		iVert = mapVert.get(this.findNearestVertKey());
		return new IndexCoordinate(iLat,iLon,iTime,iVert);
	}
	
	/**
	 * Checks if rasters are equal.
	 * @param ras1 Raster to check.
	 * @return True if 
	 */
	public boolean equals(Object o1){
	
		//ras1 = object coerced to raster
		
		GeospatialRaster0 ras1;
		
		if(!(o1 instanceof GeospatialRaster0)){
			return false;
		}else{
			ras1 = (GeospatialRaster0) o1;
		}
		
		if(!Arrays.equals(this.getLatitudes(), ras1.getLatitudes())){
			return false;
		}
		if(!Arrays.equals(this.getLongitudes(), ras1.getLongitudes())){
			return false;
		}
		if(!Arrays.equals(this.getTimes(), ras1.getTimes())){
			return false;
		}
		if(!Arrays.equals(this.getVerts(), ras1.getVerts())){
			return false;
		}
		if(!sVarName.equals(ras1.sVarName)){
			return false;
		}
		if(!sVarUnits.equals(ras1.sVarUnits)){
			return false;
		}
		return true;
	}
	
	
	/**
	 * Finds closest time key in raster to specified time value
	 * @param timValue Time value
	 * @return Closest time value
	 */
	private LocalDate findNearestTimeKey(){
		
		//timFloor = floor value
		//timCeiling = ceiling value
		
		LocalDate timFloor;
		LocalDate timCeiling;
		
		if(!tim1.isAfter(mapDate.firstKey())){
			return mapDate.firstKey();
		}else if(!tim1.isBefore(mapDate.lastKey())){
			return mapDate.lastKey();
		}else{
			timFloor = mapDate.floorKey(tim1);
			timCeiling = mapDate.ceilingKey(tim1);
			if(Days.daysBetween(timFloor, tim1).getDays()<Days.daysBetween(tim1, timCeiling).getDays()){
				return timFloor;
			}else{
				return timCeiling;
			}
		}
	}
	
	/**
	 * Finds closest vertical key in raster to specified vert value
	 * @param dVertValue Vertical value
	 * @return Closest vertical value
	 */
	private double findNearestVertKey(){
		
		//dFloor = floor value
		//dCeiling = ceiling value
		
		double dFloor;
		double dCeiling;
		
		if(dVert<=mapVert.firstKey()){
			return mapVert.firstKey();
		}else if(dVert>=mapVert.lastKey()){
			return mapVert.lastKey();
		}else{
			dFloor = mapVert.floorKey(dVert);
			dCeiling = mapVert.ceilingKey(dVert);
			if(dVert-dFloor<dCeiling-dVert){
				return dFloor;
			}else{
				return dCeiling;
			}
		}
	}
	
	/**
	 * Returns entire raster in double array format. Time and vert must be set if they are loaded. 
	 * @return Entire raster.
	 */
	public double[][] get(){
		
		//rgdOut = output
		//itr1 = iterator
		//cel1 = current cell
		
		double rgdOut[][];
		CellIterator itr1;
		Cell cel1;
		
		rgdOut = new double[iRows][iCols];
		for(int i=0;i<rgdOut.length;i++){
			for(int j=0;j<rgdOut[0].length;j++){
				rgdOut[i][j]=Double.NaN;
			}
		}
		
		itr1 = new CellIterator();
		while(itr1.hasNext()){
			cel1 = itr1.next();
			rgdOut[cel1.iLat][cel1.iLon]=cel1.dValue;
		}
		return rgdOut;
	}
	
	/**
	 * Looks up a value.
	 * @param dLat Latitude of value.
	 * @param dLon Longitude of value.
	 * @return Value at specified location.
	 */
	public double get(double dLat, double dLon){
		
		//gco1 = GeoCoordinate
		
		GeoCoordinate gco1;
		
		if(!rngLat.contains(dLat)){
			return Double.NaN;
		}
		if(!rngLon.contains(dLon)){
			return Double.NaN;
		}
		
		gco1 = new GeoCoordinate(dLat,dLon,tim1,dVert);
		return get(convertGeoCoordinateToIndexCoordinate(gco1));
	}
	
	/**
	 * Looks up value by indices
	 * @param ico1 Indices of location: latitude, longitude, time. A time index of Integer.MAX_VALUE indicates no temporal data.
	 * @return Value at given location and time.
	 */
	private double get(IndexCoordinate ico1){
		return get(ico1.iLat,ico1.iLon,ico1.iTime,ico1.iVert);
	}
	
	/**
	 * Gets list of loaded latitudes.
	 */
	public double[] getLatitudes(){
		
		//rgdOut = output
		//i1 = counter
		
		double rgdOut[];
		int i1;
		
		rgdOut = new double[mapLat.size()];
		i1 = 0;
		for(Double d:mapLat.keySet()){
			rgdOut[i1] = d;
			i1++;
		}
		return rgdOut;
	}
	
	/**
	 * Gets list of loaded longitudes.
	 */
	public double[] getLongitudes(){
		
		//rgdOut = output
		//i1 = counter
		
		double rgdOut[];
		int i1;
		
		rgdOut = new double[mapLon.size()];
		i1 = 0;
		for(Double d:mapLon.keySet()){
			rgdOut[i1] = d;
			i1++;
		}
		return rgdOut;
	}
	
	/**
	 * Gets the current time.
	 * @return Time in LocalDate format
	 */
	public LocalDate getTime(){
		return this.tim1;
	}
	
	/**
	 * Gets list of loaded times.
	 */
	public LocalDate[] getTimes(){
		
		//rgdOut = output
		//i1 = counter
		
		LocalDate rgtOut[];
		int i1;
		
		rgtOut = new LocalDate[mapDate.size()-1];
		i1 = 0;
		for(LocalDate tim1:mapDate.keySet()){
			if(!tim1.equals(this.NULL_TIME)){
				rgtOut[i1] = tim1;
				i1++;
			}
		}
		return rgtOut;
	}
	
	/**
	 * Gets the current vert setting.
	 * @return Current vert.
	 */
	public double getVert(){
		return this.dVert;
	}
	
	/**
	 * Gets list of loaded vert values.
	 */
	public double[] getVerts(){
		
		//rgdOut = output
		//i1 = counter
		
		double rgdOut[];
		int i1;
		
		rgdOut = new double[mapVert.size()-1];
		i1 = 0;
		for(Double d:mapVert.keySet()){
			if(d!=this.NULL_VERT){
				rgdOut[i1] = d;
				i1++;
			}
		}
		return rgdOut;
	}

	/**
	 * Checks if raster has time information
	 * @return True if time information is loaded; false otherwise
	 */
	public boolean hasTime(){
		if(mapDate.size()>1){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Checks if raster has elevation information
	 * @return True if elevation information is loaded; false otherwise
	 */
	public boolean hasVert(){
		if(mapVert.size()>1){
			return true;
		}else{
			return false;
		}
	}
	
	protected void initializeTimes(Set<LocalDate> setTimes){
		initializeTimes(setTimes.toArray(new LocalDate[setTimes.size()]));
	}
	
	protected void initializeTimes(LocalDate[] rgt1){
		for(LocalDate tim1:rgt1){
			if(!mapDate.containsKey(tim1)){
				mapDate.put(tim1, iDateIndex);
				iDateIndex++;
			}
		}
	}

	protected void initializeVerts(double[] rgd1){
		for(Double dVert:rgd1){
			if(!mapVert.containsKey(dVert)){
				mapVert.put(dVert, iVertIndex);
				iVertIndex++;
			}
		}	
	}
	
	protected void initializeVerts(Set<Double> setVerts){
		
		//rgd1 = array in Double format
		
		Double rgd1[];
		
		rgd1 = setVerts.toArray(new Double[setVerts.size()]);
		initializeVerts(ArrayUtils.toPrimitive(rgd1));
	}
	
	protected void initialize(double dLatResolution, double dLonResolution, Range<Double> rngLat, Range<Double> rngLon, String sVarName, String sVarUnits){
		
		//i1 = current counter
		//d1 = current value being added to map
		//iMax = maximum value for counter
		
		int i1;
		int iMax;
		double d1;

		//saving variables
		this.sVarName=sVarName;
		this.sVarUnits=sVarUnits;
		//this.plyMask = plyMask;
		this.dLatResolution = dLatResolution;
		this.dLonResolution = dLonResolution;
		this.rngLat = rngLat;
		this.rngLon = rngLon;
		
		//loading treemaps
		mapLat = new TreeMap<Double,Integer>();
		mapLon = new TreeMap<Double,Integer>();
		mapDate = new TreeMap<LocalDate,Integer>();
		mapDate.put(NULL_TIME, 0);
		mapVert = new TreeMap<Double,Integer>();
		mapVert.put(NULL_VERT, 0);
		
		//initializing indices
		iDateIndex=1;
		iVertIndex=1;
		
		iMax=0;
		for(int i=0;i<(rngLat.upperEndpoint()-rngLat.lowerEndpoint())/dLatResolution+5;i++){
			d1 = Precision.round(i*dLatResolution + rngLat.lowerEndpoint(),9);
			if(d1>rngLat.upperEndpoint()-dLatResolution){
				break;
			}
			iMax++;
		}
		i1=0;
		for(int i=0;i<(rngLat.upperEndpoint()-rngLat.lowerEndpoint())/dLatResolution+5;i++){
			d1 = Precision.round(i*dLatResolution + rngLat.lowerEndpoint(),9);
			if(d1>rngLat.upperEndpoint()-dLatResolution){
				break;
			}
			mapLat.put(d1, iMax-i1-1);
			i1++;
		}
		
		i1=0;
		for(int i=0;i<(rngLon.upperEndpoint()-rngLon.lowerEndpoint())/dLonResolution+5;i++){
			d1 = Precision.round(i*dLonResolution + rngLon.lowerEndpoint(),9);
			if(d1>rngLon.upperEndpoint()-dLonResolution){
				break;
			}
			mapLon.put(d1, i1);
			i1++;
		}
		iRows = mapLat.size();
		iCols = mapLon.size();
		lstCoords = new ArrayList<GeoCoordinate>(10000);
	}

	/**
	 * Removes an entry by replacing it with NaN. 
	 */
	public void remove(double dLat, double dLon){
		this.put(dLat, dLon, Double.NaN);
	}
	
	/**
	 * Saves value to raster
	 * @param dLat Latitude.
	 * @param dLon Longitude.
	 * @param dValue Value to be written
	 */
	public void put(double dLat, double dLon, double dValue){
		
		//ico1 = indices
		
		IndexCoordinate ico1;
		
		//checking mask
		//if(plyMask!=null && !plyMask.contains(dLat, dLon)){
		//	return;
		//}
		
		//updating index maps
		if(!mapDate.containsKey(tim1)){
			mapDate.put(tim1, iDateIndex);
			iDateIndex++;
		}
		if(!mapVert.containsKey(dVert)){
			mapVert.put(dVert, iVertIndex);
			iVertIndex++;
		}
		
		//saving value
		ico1 = convertGeoCoordinateToIndexCoordinate(new GeoCoordinate(dLat,dLon,tim1,dVert));
		this.put(ico1.iLat, ico1.iLon, ico1.iTime, ico1.iVert, dValue);
				
		//updating list of coordinates
		lstCoords.add(new GeoCoordinate(mapLat.floorKey(dLat),mapLon.floorKey(dLon),tim1,dVert));
	}

	/**
	 * Sets time value for reading and writing.
	 * @param tim1 Time to read and write from.
	 */
	public void setTime(LocalDate tim1){
		this.tim1 = tim1;
	}

	/**
	 * Sets vertical value for reading and writing.
	 * @param dVert Vertical to read and write from.
	 */
	public void setVert(Double dVert){
		this.dVert = dVert;
	}

	/**
	 * Unsets time for data that do not have time coordinates.
	 */
	public void unsetTime(){
		tim1 = NULL_TIME;
	}

	/**
	 * Unsets vertical data for data that do not have vertical coordinates
	 */
	public void unsetVert(){
		dVert=NULL_VERT;
	}

	/**
	 * Gets all loaded time and vert combinations
	 */
	public HashSet<TimeVert> getAllTimeVertCombinations(){
		
		//set1 = output
		//rgdVerts = verts
		//rgtTimes = times
		
		double rgdVerts[];
		LocalDate rgtTimes[];
		HashSet<TimeVert> set1;
		
		rgdVerts = this.getVerts();
		rgtTimes = this.getTimes();
		
		if(rgdVerts.length==0){
			rgdVerts = new double[]{this.NULL_VERT};
		}
		if(rgtTimes.length==0){
			rgtTimes = new LocalDate[]{this.NULL_TIME};
		}
		set1 = new HashSet<TimeVert>(rgdVerts.length*rgtTimes.length);
		for(int i=0;i<rgdVerts.length;i++){
			for(int j=0;j<rgtTimes.length;j++){
				set1.add(new TimeVert(rgtTimes[j],rgdVerts[i]));
			}
		}
		return set1;
	}
	
	/**
	 * Gets all loaded time and vert combinations
	 */
	public TimeVert[] getAllTimeVertCombinations0(){
		
		//rgt1 = output
		//rgdVerts = verts
		//rgtTimes = times
		//i1 = counter
		
		double rgdVerts[];
		LocalDate rgtTimes[];
		TimeVert rgt1[];
		int i1;
		
		rgdVerts = this.getVerts();
		rgtTimes = this.getTimes();
		
		if(rgdVerts.length==0){
			rgdVerts = new double[]{this.NULL_VERT};
		}
		if(rgtTimes.length==0){
			rgtTimes = new LocalDate[]{this.NULL_TIME};
		}
		rgt1 = new TimeVert[rgdVerts.length*rgtTimes.length];
		i1 = 0;
		for(int i=0;i<rgdVerts.length;i++){
			for(int j=0;j<rgtTimes.length;j++){
				rgt1[i1] = new TimeVert(rgtTimes[j],rgdVerts[i]);
				i1++;
			}
		}
		return rgt1;
	}

	public class TimeVert{	
		public LocalDate tim1;
		public double dVert;
		
		public TimeVert(LocalDate tim1, double dVert){
			this.tim1 = tim1;
			this.dVert = dVert;
		}
	}
	
	public class Cell{
		
		/**Latitude range**/
		public Range<Double> rngLat;
		
		/**Longitude range**/
		public Range<Double> rngLon;
		
		/**Center latitude**/
		public double dLat;
		
		/**Center longitude**/
		public double dLon;
		
		/**Date**/
		public LocalDate tim1;
		
		/**Vertical**/
		public double dVert;
		
		/**Value**/
		public double dValue;
		
		/**Latitude index**/
		public int iLat;
		
		/**Longitude index*/
		public int iLon;
		
		/**Date index.**/
		public int iTime;
		
		/**Vertical index**/
		public int iVert;
		
	}

	public class CellIterator implements Iterator<Cell>{
	
		/**List of coordinates to consider.**/
		private ArrayList<GeoCoordinate> lst1;
		
		/**Internal iterator**/
		private Iterator<GeoCoordinate> itr1;
		
		/**
		 * Constructor.
		*/
		public CellIterator(){
			
			//timKey = time key
			//dVertKey = vert key
			
			LocalDate timKey;
			double dVertKey;
			
			lst1 = new ArrayList<GeoCoordinate>(lstCoords.size());
			for(GeoCoordinate crd1:lstCoords){
				timKey = findNearestTimeKey();
				dVertKey = findNearestVertKey();
				if(tim1.equals(NULL_TIME) && dVert==NULL_VERT){
					lst1.add(crd1);
				}else{
					if(tim1.equals(NULL_TIME) && dVert!=NULL_VERT){
						if(crd1.dVert==dVertKey){
							lst1.add(crd1);
						}
					}else if(!tim1.equals(NULL_TIME) && dVert==NULL_VERT){
						if(crd1.tim1.equals(timKey)){
							lst1.add(crd1);
						}
					}else if(!tim1.equals(NULL_TIME) && dVert!=NULL_VERT){
						if(crd1.tim1.equals(timKey) && crd1.dVert==dVertKey){
							lst1.add(crd1);
						}
					}
				}
			}
			itr1 = lst1.iterator();
		}
		
		@Override
		public boolean hasNext() {
			return itr1.hasNext();
		}
	
		@Override
		public Cell next(){
			
			//geo1 = current geocoordinates
			//cel1 = raster cell
			//ind1 = current indices
			
			GeoCoordinate geo1;
			Cell cel1;
			IndexCoordinate ind1;
			
			geo1 = itr1.next();
			cel1 = new Cell();
			cel1.rngLat = Range.closedOpen(geo1.dLat,geo1.dLat+dLatResolution);
			cel1.rngLon = Range.closedOpen(geo1.dLon,geo1.dLon+dLonResolution);
			cel1.dLat = geo1.dLat+dLatResolution/2.;
			cel1.dLon = geo1.dLon+dLonResolution/2.;
			cel1.tim1 = geo1.tim1;
			cel1.dVert = geo1.dVert;
			cel1.dValue = get(cel1.dLat, cel1.dLon);
			ind1 = convertGeoCoordinateToIndexCoordinate(geo1);
			cel1.iLat = ind1.iLat;
			cel1.iLon = ind1.iLon;
			cel1.iTime = ind1.iTime;
			cel1.iVert = ind1.iVert;
			return cel1;
		}
	
		@Override
		public void remove() {
		}
	}

	/**
	 * Geographic coordinates in table.
	 * @author jladau
	 */
	private class GeoCoordinate{
		
		public double dLat;
		public double dLon;
		public LocalDate tim1;
		public double dVert;
		
		public GeoCoordinate(double dLat, double dLon, LocalDate tim1, double dVert){
			this.dLat = dLat;
			this.dLon = dLon;
			this.tim1 = tim1;
			this.dVert = dVert;
		}
		
		public String toString(){
			return dLat + "," + dLon;
		}
	}

	/**
	 * Integer coordinates in table.
	 * @author jladau
	 */
	private class IndexCoordinate{
		
		public int iLat;
		public int iLon;
		public int iTime;
		public int iVert;
		
		public IndexCoordinate(int iLat, int iLon, int iTime, int iVert){
			this.iLat = iLat;
			this.iLon = iLon;
			this.iTime = iTime;
			this.iVert = iVert;
		}
	}
}
