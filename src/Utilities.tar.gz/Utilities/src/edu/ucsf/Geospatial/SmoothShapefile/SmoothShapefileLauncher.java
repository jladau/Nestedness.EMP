package edu.ucsf.Geospatial.SmoothShapefile;

import java.util.ArrayList;

import edu.ucsf.geospatial.GeographicPointBounds;
import edu.ucsf.geospatial.GeospatialRaster;
import edu.ucsf.geospatial.SphericalCapEarth;
import edu.ucsf.geospatial.SphericalMultiPolygon;
import edu.ucsf.geospatial.SphericalMultiPolygon.SphericalPolygonEdge;
import edu.ucsf.geospatial.SphericalMultiPolygon.SphericalPolygonIterator;
import edu.ucsf.geospatial.WktIO;
import edu.ucsf.io.ArgumentIO;
import edu.ucsf.io.DataIO;
import edu.ucsf.io.ShapefileIO;

/**
 * This code finds the exterior parallel sets of the polygons in shapefile.
 * @author jladau
 */

public class SmoothShapefileLauncher {

	public static void main(String rgsArgs[]) throws Exception{
		
		//arg1 = arguments
		//shp1 = shapefile io object
		//ply1 = current smoothed polygon
		//lstOut = output
		//lstGrid = initial grid
		
		ShapefileIO shp1;
		ArgumentIO arg1;
		SphericalMultiPolygon ply1;
		ArrayList<String> lstOut;
		ArrayList<GeographicPointBounds> lstGrid;
		
		//loading arguments
		arg1 = new ArgumentIO(rgsArgs);
				
		//loading shapefile
		shp1 = new ShapefileIO(
				arg1.getValueString("sShapefilePath"),
				arg1.getValueString("sIDHeader"));
		
		//initializing output
		lstOut = new ArrayList<String>();
		lstOut.add(WktIO.header());
		DataIO.writeToFile(lstOut, arg1.getValueString("sOutputPath"));
		
		//loading grid
		lstGrid = GeospatialRaster.globalBoundsGrid(10.);
		
		//looping through polygons
		while(shp1.hasNext()){	
			shp1.next();
			System.out.println("Smoothing polygon " + shp1.getID() + "...");
			
			//TODO smooth polygon here
			
			lstOut = new ArrayList<String>();
			lstOut.add(WktIO.toWKT(ply1, shp1.getID()));
			DataIO.writeToFile(lstOut, arg1.getValueString("sOutputPath"),true);
			return;
		}
		
		//terminating
		System.out.println("Done.");
	}
	
	private static SphericalMultiPolygon smoothPolygon(SphericalMultiPolygon ply1, double dSmoothingRadius, ArrayList<GeographicPointBounds> lstGrid){
		
		
		
		
	}
}
