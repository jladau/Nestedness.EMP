package edu.ucsf.deprecated;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import edu.ucsf.base.Permutation;
import edu.ucsf.geospatial.EarthGeometry;
import edu.ucsf.io.BiomIO;
import static edu.ucsf.unittested.base.ExtendedMath.*;

//TODO write unit tests

public class DistanceDecay0 {

	/**Returns the distance between a pair of samples**/
	private HashMap<SamplePair,Double> mapDistance;
	
	/**Returns the bray-curtis distance between a pair of samples**/
	private HashMap<SamplePair,Double> mapBrayCurtis;
	
	/**BIOM object**/
	private BiomIO bio1;
	
	/**Observed slope**/
	private double dSlopeObserved;
	
	public DistanceDecay0(BiomIO bio1){
		
		//spr1 = current sample pair
		//ert1 = Earth geometry object
		//iCounter = counter
		
		EarthGeometry ert1;
		SamplePair spr1;
		int iCounter=0;
		
		//saving biom object
		this.bio1 = bio1;
		
		//looping through pairs of samples
		ert1 = new EarthGeometry();
		mapDistance = new HashMap<SamplePair,Double>(bio1.axsSample.size()*bio1.axsSample.size()/2);
		mapBrayCurtis = new HashMap<SamplePair,Double>(bio1.axsSample.size()*bio1.axsSample.size()/2);
		
		//****************************
		//mapDistance.put(new SamplePair("frogs","toads"), 9999.);
		//System.out.println("frogs".hashCode());
		//System.out.println((new SamplePair("frogs","toads")).equals(new SamplePair("frogs","toads")));
		//System.out.println(mapDistance.containsKey(new SamplePair("frogs","toads")));
		//System.out.println(mapDistance.containsKey(new SamplePair("toads","frogs")));
		//System.out.println(mean(new double[]{1.,2.,3.,4.}));
		//****************************
		
		for(String s:bio1.axsSample.getIDs()){
			for(String t:bio1.axsSample.getIDs()){
				if(!s.equals(t)){
					spr1 = new SamplePair(s,t);
					if(!mapDistance.containsKey(spr1)){
						
						iCounter++;
						if(iCounter%100==0){
							System.out.println("Analyzing distance " + iCounter + "...");
						}
						
						mapDistance.put(spr1, ert1.orthodromicDistanceWGS84(
								Double.parseDouble(bio1.axsSample.getMetadata(s).get("latitude")), 
								Double.parseDouble(bio1.axsSample.getMetadata(s).get("longitude")), 
								Double.parseDouble(bio1.axsSample.getMetadata(t).get("latitude")), 
								Double.parseDouble(bio1.axsSample.getMetadata(t).get("longitude"))));
						mapBrayCurtis.put(spr1, getBrayCurtis(bio1,s,t));
					}
				}
			}
		}
		loadObservedSlope();
	}
	
	private void loadObservedSlope(){
		
		//lstX = list of distances
		//lstY = list of bray-curtises
		
		ArrayList<Double> lstX;
		ArrayList<Double> lstY;
		
		//finding non-randomized slope
		lstX = new ArrayList<Double>(mapDistance.size());
		lstY = new ArrayList<Double>(mapDistance.size());
		for(SamplePair spr1:mapDistance.keySet()){
			lstX.add(mapDistance.get(spr1));
			
			//********************************
			//if(!mapBrayCurtis.containsKey(spr1)){
			//	System.out.println("EGEDS");
			//}
			//********************************
			
			lstY.add(mapBrayCurtis.get(spr1));
		}
		
		//***********************
		//for(int i=0;i<lstX.size();i++){
		//	System.out.println(lstX.get(i) + "," + lstY.get(i));
		//}
		//***********************
		
		dSlopeObserved = slope(lstX, lstY);
	}
	
	public double findPValue(int iIterations){
		
		//d1 = number of randomizations greater than the observed slope
		
		double d1=0.;
		
		for(int i=0;i<iIterations;i++){
			if(findRandomizedSlope()>=dSlopeObserved){
				d1++;
			}
		}
		return d1/((double) iIterations);
	}
	
	/*
	public HashMap<String,Double> findJacknifeSlopes(){
		
		//mapOut = output
		//lstX = list of distances
		//lstY = list of bray-curtises
		
		ArrayList<Double> lstX;
		ArrayList<Double> lstY;
		HashMap<String,Double> mapOut;
		
		mapOut = new HashMap<String,Double>(bio1.axsSample.size());
		for(String s:bio1.axsSample.getIDs()){
			lstX = new ArrayList<Double>(mapDistance.size());
			lstY = new ArrayList<Double>(mapDistance.size());
			for(SamplePair spr1:mapDistance.keySet()){
				if(!spr1.contains(s)){
					lstX.add(mapDistance.get(spr1));
					lstY.add(mapBrayCurtis.get(spr1));
				}
			}
			mapOut.put(s, slope(lstX, lstY));
		}
		return mapOut;
	}
	*/
	
	public double getSlope(){
		return this.dSlopeObserved;
	}
	
	private double findRandomizedSlope(){
		
		//spr1 = current sample pair
		//per1 = permutation
		//lstX = list of distances
		//lstY = list of bray-curtises
		
		ArrayList<Double> lstX;
		ArrayList<Double> lstY;
		Permutation<String> per1;
		SamplePair spr1;
		
		per1 = new Permutation<String>(new ArrayList<String>(bio1.axsSample.getIDs()));
		per1.loadRandomPermutation();
		lstX = new ArrayList<Double>(mapDistance.size());
		lstY = new ArrayList<Double>(mapDistance.size());
		for(String s:bio1.axsSample.getIDs()){
			for(String t:bio1.axsSample.getIDs()){
				if(!s.equals(t)){
					spr1 = new SamplePair(per1.getImage(s),per1.getImage(t));
					if(mapDistance.containsKey(spr1)){
						lstX.add(mapDistance.get(spr1));
						lstY.add(getBrayCurtis(bio1,per1.getImage(s),per1.getImage(t)));
					}
				}
			}
		}
		

		//************************
		//System.out.println("randomized slope=" + slope(lstX, lstY));
		//************************
		
		
		return slope(lstX, lstY);
		
	}
	
	public double getDistance(SamplePair spr1){
		return mapDistance.get(spr1);
	}
	
	public double getBrayCurtis(SamplePair spr1){
		return mapBrayCurtis.get(spr1);
	}
	
	public Set<SamplePair> getSamplePairs(){
		return mapBrayCurtis.keySet();
	}
	
	private double getBrayCurtis(BiomIO bio1, String sSample1, String sSample2){
		
		//dNum = numerator
		//dDen = denominator
		//d1 = current first value
		//d2 = current second value
		
		double dNum; double dDen; double d1; double d2;
		
		dNum = 0;
		dDen = 0;
		for(String s:bio1.axsObservation.getIDs()){
			d1 = bio1.getValueByIDs(s, sSample1);
			d2 = bio1.getValueByIDs(s, sSample2);
			dNum+=Math.abs(d1-d2);
			dDen+=(d1+d2);
		}
		if(dDen==0){
			return Double.NaN;
		}else{
			return dNum/dDen;
		}
	}
	
	public class SamplePair{
		
		public String sSampleID1;
		public String sSampleID2;
		
		private SamplePair(String sSampleID1,String sSampleID2){		
			this.sSampleID1 = sSampleID1;
			this.sSampleID2 = sSampleID2;
		}
		
		public boolean equals(Object o1){
			
			//spr1 = sample pair being tested
			
			SamplePair spr1;
			
			if(o1 instanceof SamplePair){
				spr1 = (SamplePair) o1;
				if(spr1.sSampleID1.equals(sSampleID1) && spr1.sSampleID2.equals(sSampleID2)){
					return true;
				}
				if(spr1.sSampleID1.equals(sSampleID2) && spr1.sSampleID2.equals(sSampleID1)){
					return true;
				}
			}
			return false;
		}
		
		public int hashCode(){
			return sSampleID1.hashCode() + sSampleID2.hashCode();
		}
		
		public boolean contains(String sSampleID){
			if(sSampleID1.equals(sSampleID) || sSampleID2.equals(sSampleID)){
				return true;
			}else{
				return false;
			}
		}
		
		public String toString(){
			return sSampleID1 + "," + sSampleID2;
		}
	}
}
