package edu.ucsf.geospatial;

import com.google.common.collect.HashBasedTable;
import static java.lang.Math.*;

import java.util.ArrayList;
import java.util.HashSet;

import javax.swing.text.NumberFormatter;

import edu.ucsf.geospatial.SphericalCapEarth;
import edu.ucsf.geospatial.SphericalMultiPolygon;
import static edu.ucsf.geospatial.EarthGeometry.*;

/**
 * Sampling region for beta-diversity range shapes analysis
 * @author jladau
 */

public class SphericalCapEarth_SamplingRegion_SarEar extends SphericalCapEarth_SamplingRegion{
	
	/**Set of global perimeter and area values**/
	//private HashSet<Double[]> setGlobal;
	
	/**Set of regional perimeter and area values**/
	//private HashSet<Double[]> setRegional;
	
	/**Cap for calculating interior parallel set area and perimeter**/
	private SphericalCapEarth cap1 = null;
	
	/**Table  of perimeters and areas: rows are species names, columns are radii. First entry is perimeter, second entry is area**/
	private HashBasedTable<String,String,Double[]> tbl1;
	
	/**Smoothing radius**/
	private double dSmoothingRadius;
	
	/**ID**/
	private String sID;
	
	/**Cap as polygon**/
	private SphericalMultiPolygon plyCap;
	
	/**Flag for whether merged polygon is intersected**/
	private boolean bIntersectsMerged;
	
	public SphericalCapEarth_SamplingRegion_SarEar(
			double dSamplingRegionRadius, 
			double dLatCenter, 
			double dLonCenter, 
			double dSmoothingRadius, 
			int iRandomSeed, 
			String sID){
		super(dSamplingRegionRadius, dLatCenter, dLonCenter, Double.NaN, iRandomSeed);
		tbl1 = HashBasedTable.create(10000,2);
		cap1 = new SphericalCapEarth(dSamplingRegionRadius - dSmoothingRadius, dLatCenter, dLonCenter, iRandomSeed);
		plyCap = cap1.toPolygon(360);
		this.dSmoothingRadius = dSmoothingRadius;
		this.sID = sID;
		this.bIntersectsMerged = false;
	}
	
	public void loadMergedIntersection(SphericalMultiPolygon plyMerged){
		if(plyMerged.intersects(this)){
			this.bIntersectsMerged=true;
		}else{
			this.bIntersectsMerged=false;
		}
	}
	
	public boolean intersectsMerged(){
		return bIntersectsMerged;
	}
	
	public void savePerimeterArea(SphericalMultiPolygon ply1, double dGlobalPerimeter, double dGlobalArea, String sSpecies){
		
		if(ply1.intersects(cap1)){		
			tbl1.put(sSpecies, "global", new Double[]{dGlobalPerimeter, dGlobalArea, 0.});
			double d1 = ply1.area(cap1);
			if(abs(d1-cap1.area())<1){
				tbl1.put(sSpecies, "regional", new Double[]{0., cap1.area(), cap1.perimeter()});	
			}else{
				tbl1.put(sSpecies, "regional", new Double[]{ply1.perimeter(cap1), d1, plyCap.perimeter(ply1)});	
			}
			iNumberOfSpecies++;
		}
	}
	
	public double prevalencePredictionEuclidean(double dRadius, String sSpecies, String sScale) throws Exception{
		
		//d1 = output
		//dF = area of region
		//dL = perimeter of region
		//dR = difference between radius and smoothing radius
		//rgd1 = current observation
		//dValue = output value
		//dc = cutoff value
		
		double dc;
		double dValue = Double.NaN;
		double dF;
		double dL;
		double dR;
		Double rgd1[];
		double c2;
		double c0;
		double c1;
		
		dL = cap1.perimeter();
		dF = cap1.area();
		dR = dRadius - dSmoothingRadius;
		if(!tbl1.contains(sSpecies, sScale)){
			return 0.;
		}
		rgd1 = tbl1.get(sSpecies, sScale);

		//global estimator
		if(sScale.equals("global")){
			dValue = (rgd1[1] + rgd1[0]*dR + PI*dR*dR)/(rgd1[1] + dF + rgd1[0]*dL/(2.*PI));
		
		//regional estimator
		}else if(sScale.equals("regional")){
			
			c2 = rgd1[2];
			c0 = rgd1[0];
			c1 = rgd1[1];
			dc = (-(c2-dL-c0) - sqrt((c0-c2+dL)*(c0-c2+dL) + 4.*(c1-dF)*PI))/(2.*PI);
			
			//**********************
			if(Double.isNaN(dc)){
				dc=Double.MAX_VALUE;
			}
			//dc=Double.MAX_VALUE;
			//**********************
			
			//**********************
			if(dR>dc){
				dValue=1.;
			}else{
				dValue = (rgd1[1] + dR*(rgd1[0] - rgd1[2]))/(dF - dL*dR + PI*dR*dR);
			}
			//dValue = (rgd1[1] + dR*(rgd1[0] - rgd1[2]))/(dF - dL*dR + PI*dR*dR);
			if(dValue>1){
				dValue=1;
			}else if(dValue<0){
				dValue=1;
			}
			//**********************
		}	
		return dValue;
	}
	
	
	public double richnessPredictionEuclidean(double dRadius, String sScale) throws Exception{
		
		//d1 = output
		
		double d1;
		
		d1 = 0.;
		for(String s:tbl1.rowKeySet()){
			d1 += prevalencePredictionEuclidean(dRadius, s, sScale);
		}
		return d1;
	}
	
	@Deprecated
	public String sarPredictionExpression(){
		
		//dF = area of region
		//dL = perimeter of region
		//rgd1 = current observation
		//d0 = zeroeth order coefficient
		//d1 = first order coefficient
		//dCount = count
		
		double dF;
		double dL;
		Double rgd1[];
		double d0;
		double d1;
		double dCount;
		
		dL = cap1.perimeter();
		dF = cap1.area();
		d0 = 0.;
		d1 = 0.;
		dCount = 0.;
		for(String s:tbl1.rowKeySet()){
			rgd1 = tbl1.get(s, cap1.radius());
			d0 += rgd1[1];
			d1 += rgd1[0] - rgd1[2];
			dCount++;
		}
		
		return "(" + d0/dCount + " + r*" + d1/dCount + ")/(" + dF + " - r*"  + dL + " + pi*r^2)";
	}
	
	@Deprecated
	public double sarPredictionSpherical(double dRadius, String sScale) throws Exception{
		
		//d1 = output
		//dF = area of region
		//dL = perimeter of region
		//rgd1 = current observation
		//d2 = radius key
		//dF2 = area of exterior parallel set of range
		//dL2 = perimeter of exterior parallel set of range
				
		double d2;
		double d1;
		double dF;
		double dL;
		Double rgd1[];
		double dF2;
		double dL2;
		
		d1 = 0.;
		dL = cap1.perimeter();
		dF = cap1.area();
		if(sScale.equals("global")){
			d2 = -9999;
		}else if(sScale.equals("regional")){
			d2 = cap1.radius();
		}else{
			throw new Exception("Invalid scale.");
		}
		for(String s:tbl1.rowKeySet()){
			rgd1 = tbl1.get(s, d2);
			dF2 = rgd1[1]*cos((dRadius-dSmoothingRadius)/EARTH_RADIUS)+rgd1[0]*EARTH_RADIUS*sin((dRadius-dSmoothingRadius)/EARTH_RADIUS)-2.*PI*EARTH_RADIUS_SQUARED*(cos((dRadius-dSmoothingRadius)/EARTH_RADIUS)-1.);
			dL2 = rgd1[0] + 2.*PI*(dRadius-dSmoothingRadius);
			d1 += dF2/(dF2 + dF + dL2*dL/(2.*PI));
		}
		
		return d1;
	}
	
	public String getID(){
		return sID;
	}
}
