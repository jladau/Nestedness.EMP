package edu.ucsf.deprecated;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import edu.ucsf.base.ClusterIteratorTest;
import edu.ucsf.base.ExtendedCollectionsTest;
import edu.ucsf.base.ExtendedMathTest;
import edu.ucsf.base.GraphTest;
import edu.ucsf.base.HashMap_AdditiveDoubleTest;
import edu.ucsf.base.IntervalTest;
import edu.ucsf.base.PermutationTest;
import edu.ucsf.base.PropertyTest;
import edu.ucsf.geospatial.EarthGeometryTest;
import edu.ucsf.geospatial.SpatialAutocorrelationTest;
import edu.ucsf.geospatial.SpatialWeightsMatrixTest;
import edu.ucsf.io.ArgumentIOTest;
import edu.ucsf.io.BiomIOTest;
import edu.ucsf.io.DataIOTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	ArgumentIOTest.class,
	BiomIOTest.class,
	ClusterIteratorTest.class,
	DataIOTest.class,
	EarthGeometryTest.class,
	ExtendedCollectionsTest.class,
	ExtendedMathTest.class,
	GraphTest.class,
	HashMap_AdditiveDoubleTest.class,
	IntervalTest.class,
	PermutationTest.class,
	PropertyTest.class,
	SpatialAutocorrelationTest.class,
	SpatialWeightsMatrixTest.class,
})

public class RunAllUnitTests {
}