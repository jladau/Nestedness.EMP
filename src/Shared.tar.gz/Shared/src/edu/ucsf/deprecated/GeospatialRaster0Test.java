package edu.ucsf.deprecated;


import static org.junit.Assert.*;

import java.util.HashSet;

import org.apache.commons.lang.ArrayUtils;
import org.joda.time.LocalDate;
import org.junit.Test;
import com.google.common.collect.Range;

import edu.ucsf.geospatial.GeospatialRaster;

public class GeospatialRaster0Test{

	//ras1 = raster without temporal data
	//ras2 = raster with temporal data
	//ras3 = raster with vertical data
	//ras4 = raster with temporal and vertical data
	//ras5 = masked raster
	//rgt1 = date array
	//rgd1 = vertical value array
	
	private GeospatialRaster0 ras1;
	private GeospatialRaster0 ras2;
	private GeospatialRaster0 ras3;
	private GeospatialRaster0 ras4;
	//private GeospatialRaster ras5;	
	private LocalDate rgt1[];
	private double rgd1[];
	
	public GeospatialRaster0Test(){
		initialize();	
	}

	private void initialize(){
		
		ras1 = new GeospatialRaster0(0.1,1.0,Range.closed(10., 20.),Range.closed(-100., -80.),"Raster1","Units1");
		ras2 = new GeospatialRaster0(0.1,1.0,Range.closed(10., 20.),Range.closed(-100., -80.),"Raster2","Units2");
		ras3 = new GeospatialRaster0(0.1,1.0,Range.closed(10., 20.),Range.closed(-100., -80.),"Raster3","Units3");
		ras4 = new GeospatialRaster0(0.1,1.0,Range.closed(10., 20.),Range.closed(-100., -80.),"Raster4","Units4");
		
		rgt1 = new LocalDate[]{new LocalDate(2010,5,15), new LocalDate(2011,7,12)};
		rgd1 = new double[]{-10.,0.,50.};
		for(double dLat=10.05;dLat<20.;dLat+=0.1){
			for(double dLon=-99.5;dLon<-80;dLon+=1.0){
				ras1.put(dLat, dLon, dLat*dLon);
				for(int i=0;i<rgt1.length;i++){
					ras2.setTime(rgt1[i]);
					ras2.put(dLat, dLon, dLat*dLon*(i+1));
					for(int j=0;j<rgd1.length;j++){
						ras4.setTime(rgt1[i]);
						ras4.setVert(rgd1[j]);
						ras4.put(dLat, dLon, dLat*dLon*(i+1)+rgd1[j]);
					}
				}
				for(int j=0;j<rgd1.length;j++){
					ras3.setVert(rgd1[j]);
					ras3.put(dLat, dLon, dLat*dLon+rgd1[j]);
				}
			}
		}
	}
	
	@Test
	public void getAllTimeVertCombinations_CombinationsGotten_CombinationsCorrect(){
	
		//set1 = set of all combinations
		
		HashSet<GeospatialRaster0.TimeVert> set1;
		
		set1 = ras4.getAllTimeVertCombinations();
		assertEquals(6,set1.size(),0.00001);
		for(GeospatialRaster0.TimeVert tvt1:set1){
			assertTrue(ArrayUtils.contains(rgt1, tvt1.tim1));
			assertTrue(ArrayUtils.contains(rgd1, tvt1.dVert));
		}
	}
	
	@Test
	public void remove_EntryRemoved_EntryGone(){
		assertEquals(10.05*-99.5,ras1.get(10.05, -99.5),0.000000001);
		ras1.remove(10.05,  -99.5);
		assertTrue(Double.isNaN(ras1.get(10.05, -99.5)));
		initialize();
	}
	
	@Test
	public void clearAll_EverythingCleared_NothingLeft(){
		
		assertEquals(10.05*-99.5,ras1.get(10.05, -99.5),0.000000001);
		ras1.clearAll();
		assertTrue(Double.isNaN(ras1.get(10.05, -99.5)));
		initialize();
	}
	
	@Test
	public void put_ValuePlaced_PlacementCorrect(){
		
		ras1.put(10.07, -90.25,17.);
		assertEquals(17.,ras1.get(10.07, -90.25),0.000001);
		assertEquals(17.,ras1.get(10.01, -90.88),0.000001);
		assertNotEquals(17.,ras1.get(11.01, -90.88),0.000001);
		
		ras2.setTime(new LocalDate(2010,6,15));
		ras2.put(10.07, -90.25, 17.);
		assertEquals(17.,ras2.get(10.07, -90.25),0.000001);
		assertEquals(17.,ras2.get(10.01, -90.88),0.000001);
		assertNotEquals(17.,ras2.get(11.01, -90.88),0.000001);
		ras2.setTime(new LocalDate(2012,6,15));
		assertNotEquals(17.,ras2.get(10.07, -90.25),0.000001);
		
		ras3.setVert(11.);
		ras3.put(10.07, -90.25, 17.);
		assertEquals(17.,ras3.get(10.07, -90.25),0.000001);
		assertEquals(17.,ras3.get(10.01, -90.88),0.000001);
		assertNotEquals(17.,ras3.get(11.01, -90.88),0.000001);
		ras3.setVert(55.);
		assertNotEquals(17.,ras3.get(10.07, -90.25),0.000001);
		
		ras4.setVert(11.);
		ras4.setTime(new LocalDate(2010,6,15));
		ras4.put(10.07, -90.25, 17.);
		assertEquals(17.,ras4.get(10.07, -90.25),0.000001);
		assertEquals(17.,ras4.get(10.01, -90.88),0.000001);
		assertNotEquals(17.,ras4.get(11.01, -90.88),0.000001);
		ras4.setVert(55.);
		assertNotEquals(17.,ras4.get(10.07, -90.25),0.000001);
		ras4.setTime(new LocalDate(2012,6,15));
		assertNotEquals(17.,ras4.get(10.07, -90.25),0.000001);
		ras4.setVert(11.);
		assertNotEquals(17.,ras4.get(10.07, -90.25),0.000001);
		
		initialize();
	}
	
	@Test
	public void get_AllValuesGotten_ValuesCorrect(){
		
		//rgd1 = array of values
		//iRow = row
		//iCol = column
		
		double rgd1[][];
		int iRow; int iCol;
		
		rgd1 = ras1.get();
		iRow=0;
		for(double dLat=19.95;dLat>10.;dLat-=0.1){
			iCol=0;
			for(double dLon=-99.5;dLon<-80;dLon+=1.0){
				assertEquals(dLat*dLon,rgd1[iRow][iCol],0.00001);
				iCol++;
			}
			iRow++;
		}
	}
	
	@Test	
	public void get_ValueGotten_CorrectValueGotten(){
		
		assertEquals(10.05*-99.5,ras1.get(10.05, -99.5),0.000000001);
		assertEquals(10.05*-99.5,ras1.get(10.01, -99.75),0.000000001);
		assertEquals(19.95*-80.5,ras1.get(19.95, -80.5),0.000000001);
		assertEquals(19.95*-80.5,ras1.get(19.97, -80.1),0.000000001);
		assertEquals(Double.NaN,ras1.get(21, -110),0.000000001);
		assertEquals(Double.NaN,ras1.get(21, -90.),0.000000001);
		
		ras2.setTime(rgt1[0]);
		assertEquals(10.05*-99.5,ras2.get(10.05, -99.5),0.000000001);
		assertEquals(10.05*-99.5,ras2.get(10.01, -99.75),0.000000001);
		assertEquals(19.95*-80.5,ras2.get(19.95, -80.5),0.000000001);
		assertEquals(19.95*-80.5,ras2.get(19.97, -80.1),0.000000001);
		assertEquals(Double.NaN,ras2.get(21, -110),0.000000001);
		assertEquals(Double.NaN,ras2.get(21, -90.),0.000000001);
		ras2.setTime(rgt1[1]);
		assertNotEquals(10.05*-99.5,ras2.get(10.05, -99.5),0.000000001);
		ras2.setTime(new LocalDate(2010,6,15));
		assertEquals(10.05*-99.5,ras2.get(10.05, -99.5),0.000000001);
		ras2.setTime(new LocalDate(2011,6,15));
		assertEquals(10.05*-99.5*2.,ras2.get(10.05, -99.5),0.000000001);
		
		ras3.setVert(-1000.);
		assertEquals(10.05*-99.5-10.,ras3.get(10.05, -99.5),0.000000001);
		assertEquals(10.05*-99.5-10.,ras3.get(10.01, -99.75),0.000000001);
		assertEquals(19.95*-80.5-10.,ras3.get(19.95, -80.5),0.000000001);
		assertEquals(19.95*-80.5-10.,ras3.get(19.97, -80.1),0.000000001);
		assertEquals(Double.NaN,ras3.get(21, -110),0.000000001);
		assertEquals(Double.NaN,ras3.get(21, -90.),0.000000001);
		ras3.setVert(1000.);
		assertNotEquals(10.05*-99.5-10.,ras3.get(10.05, -99.5),0.000000001);
		assertEquals(10.05*-99.5+50.,ras3.get(10.05, -99.5),0.000000001);
		ras3.setVert(24.);
		assertEquals(10.05*-99.5+0.,ras3.get(10.05, -99.5),0.000000001);
		ras3.setVert(26.);
		assertEquals(10.05*-99.5+50.,ras3.get(10.05, -99.5),0.000000001);
		
		ras4.setVert(-1000.);
		ras4.setTime(rgt1[1]);
		assertEquals(10.05*-99.5*2.-10.,ras4.get(10.05, -99.5),0.000000001);
		assertEquals(10.05*-99.5*2.-10.,ras4.get(10.01, -99.75),0.000000001);
		assertEquals(19.95*-80.5*2.-10.,ras4.get(19.95, -80.5),0.000000001);
		assertEquals(19.95*-80.5*2.-10.,ras4.get(19.97, -80.1),0.000000001);
		assertEquals(Double.NaN,ras4.get(21, -110),0.000000001);
		assertEquals(Double.NaN,ras4.get(21, -90.),0.000000001);
		ras4.setVert(1000.);
		ras4.setTime(rgt1[0]);
		assertNotEquals(10.05*-99.5*2.-10.,ras4.get(10.05, -99.5),0.000000001);
		assertEquals(10.05*-99.5+50.,ras4.get(10.05, -99.5),0.000000001);
		

	}

	@Test
	public void hasNext_NextChecked_CorrectResult(){
		
		GeospatialRaster0.CellIterator itr1;
		
		ras1.unsetTime();
		ras1.unsetVert();
		itr1 = ras1.new CellIterator();
		for(int i=0;i<10*10*20;i++){
			assertTrue(itr1.hasNext());
			itr1.next();
		}
		assertFalse(itr1.hasNext());
		
		ras2.setTime(new LocalDate(2010,6,15));
		itr1 = ras2.new CellIterator();
		for(int i=0;i<10*10*20;i++){
			assertTrue(itr1.hasNext());
			itr1.next();
		}
		assertFalse(itr1.hasNext());
		
		ras3.unsetVert();
		itr1 = ras3.new CellIterator();
		for(int i=0;i<10*10*20*3;i++){
			assertTrue(itr1.hasNext());
			itr1.next();
		}
		assertFalse(itr1.hasNext());
		
		ras4.unsetVert();
		ras4.unsetTime();
		itr1 = ras4.new CellIterator();
		for(int i=0;i<10*10*20*3*2;i++){
			assertTrue(itr1.hasNext());
			itr1.next();
		}
		assertFalse(itr1.hasNext());
	}

	@Test
	public void next_NextCellObtained_NextCellCorrect() {
		
		GeospatialRaster0.CellIterator itr1;
		GeospatialRaster0.Cell cel1;
		
		ras1.unsetVert();
		ras1.unsetTime();
		itr1 = ras1.new CellIterator();
		
		for(int i=0;i<10*10*20;i++){
			assertTrue(itr1.hasNext());
			cel1 = itr1.next();
			if(cel1.iLat==0 && cel1.iLon==0){
				assertEquals(19.9,cel1.rngLat.lowerEndpoint(),0.0000001);
				assertEquals(-100.,cel1.rngLon.lowerEndpoint(),0.0000001);
				assertTrue(cel1.tim1.equals(new LocalDate(9999,9,9)));
			}
			if(cel1.iLat==99 && cel1.iLon==19){
				assertEquals(10.,cel1.rngLat.lowerEndpoint(),0.0000001);
				assertEquals(-81,cel1.rngLon.lowerEndpoint(),0.0000001);
				assertTrue(cel1.tim1.equals(new LocalDate(9999,9,9)));
			}
		}
		
		ras2.setTime(new LocalDate(2010,6,15));
		itr1 = ras2.new CellIterator();
		for(int i=0;i<10*10*20;i++){
			assertTrue(itr1.hasNext());
			cel1 = itr1.next();
			if(cel1.iLat==0 && cel1.iLon==0){
				assertEquals(19.9,cel1.rngLat.lowerEndpoint(),0.0000001);
				assertEquals(-100.,cel1.rngLon.lowerEndpoint(),0.0000001);
				assertTrue(cel1.tim1!=null);
			}
			if(cel1.iLat==99 && cel1.iLon==19){
				assertEquals(10.,cel1.rngLat.lowerEndpoint(),0.0000001);
				assertEquals(-81,cel1.rngLon.lowerEndpoint(),0.0000001);
				assertTrue(cel1.tim1!=null);
			}
		}
		
		ras3.setVert(50.);
		itr1 = ras3.new CellIterator();
		for(int i=0;i<10*10*20;i++){
			assertTrue(itr1.hasNext());
			cel1 = itr1.next();
			if(cel1.iLat==0 && cel1.iLon==0){
				assertEquals(19.9,cel1.rngLat.lowerEndpoint(),0.0000001);
				assertEquals(-100.,cel1.rngLon.lowerEndpoint(),0.0000001);
				assertTrue(cel1.tim1!=null);
			}
			if(cel1.iLat==99 && cel1.iLon==19){
				assertEquals(10.,cel1.rngLat.lowerEndpoint(),0.0000001);
				assertEquals(-81,cel1.rngLon.lowerEndpoint(),0.0000001);
				assertTrue(cel1.tim1!=null);
			}
		}
		
		ras4.setVert(50.);
		ras4.setTime(new LocalDate(2010,6,15));
		itr1 = ras4.new CellIterator();
		for(int i=0;i<10*10*20;i++){
			assertTrue(itr1.hasNext());
			cel1 = itr1.next();
			if(cel1.iLat==0 && cel1.iLon==0){
				assertEquals(19.9,cel1.rngLat.lowerEndpoint(),0.0000001);
				assertEquals(-100.,cel1.rngLon.lowerEndpoint(),0.0000001);
				assertTrue(cel1.tim1!=null);
			}
			if(cel1.iLat==99 && cel1.iLon==19){
				assertEquals(10.,cel1.rngLat.lowerEndpoint(),0.0000001);
				assertEquals(-81,cel1.rngLon.lowerEndpoint(),0.0000001);
				assertTrue(cel1.tim1!=null);
			}
		}
		
	}
	
	@Test
	public void getTime_TimeGotten_TimeCorrect(){
		ras2.setTime(new LocalDate(2010,6,15));
		assertEquals(new LocalDate(2010,6,15),ras2.getTime());
		ras2.unsetTime();
		assertEquals(ras2.NULL_TIME,ras2.getTime());
	}
	
	@Test
	public void getVert_VertGotten_VertCorrect(){
		ras3.setVert(50.);
		assertEquals(50.,ras3.getVert(),0.000001);
		ras3.unsetVert();
		assertEquals(ras3.NULL_VERT,ras3.getVert(),0.000001);
	}
	
	@Test
	public void getLatitudes_LatitudesGotten_LatitudesCorrect(){
		
		//rgd1 = list of latitudes
		//i1 = counter
		
		double rgd1[];
		int i1;
		
		i1=0;
		rgd1 = ras1.getLatitudes();
		for(double dLat=10.0;dLat<20.;dLat+=0.1){
			assertEquals(dLat,rgd1[i1],0.000001);
			i1++;
		}
		assertEquals(100,rgd1.length);
	}

	@Test
	public void getLongitudes_LongitudesGotten_LongitudesCorrect(){
		
		//rgd1 = list of longitudes
		//i1 = counter
		
		double rgd1[];
		int i1;
		
		i1=0;
		rgd1 = ras1.getLongitudes();
		for(double dLon=-100;dLon<-80;dLon+=1.0){
			assertEquals(dLon,rgd1[i1],0.000001);
			i1++;
		}
		assertEquals(20,rgd1.length);
	}
	
	@Test
	public void getVerts_VertsGotten_VertsCorrect(){
		
		//rgd2 = list of verts
		
		double rgd2[];
		
		rgd2 = ras4.getVerts();
		assertEquals(rgd1.length,rgd2.length);
		for(int i=0;i<rgd1.length;i++){
			assertEquals(rgd1[i],rgd2[i],0.00000001);
		}
	}
	
	@Test
	public void getTimes_TimesGotten_TimesCorrect(){
		
		//rgt2 = list of times
		
		LocalDate rgt2[];
		
		rgt2 = ras4.getTimes();
		assertEquals(rgt1.length,rgt2.length);
		for(int i=0;i<rgt1.length;i++){
			assertEquals(rgt1[i],rgt2[i]);
		}
	}
	
	@Test
	public void hasVert_Checked_Correct(){
		assertFalse(ras1.hasVert());
		assertFalse(ras2.hasVert());
		assertTrue(ras3.hasVert());
		assertTrue(ras4.hasVert());
	}
	
	@Test
	public void hasTime_Checked_Correct(){
		assertFalse(ras1.hasTime());
		assertTrue(ras2.hasTime());
		assertFalse(ras3.hasTime());
		assertTrue(ras4.hasTime());
	}
	
	@Test
	public void equals_Checked_Correct(){
		assertTrue(ras1.equals(ras1));
		assertFalse(ras1.equals(ras2));
		assertFalse(ras1.equals(ras3));
		assertTrue(ras4.equals(ras4));	
		assertFalse(ras2.equals(ras3));
	}
}
