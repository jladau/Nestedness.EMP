package edu.ucsf.base;

import java.util.ArrayList;

import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.random.JDKRandomGenerator;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.stat.correlation.PearsonsCorrelation;
import org.apache.commons.math3.stat.descriptive.moment.Mean;
import org.apache.commons.math3.stat.descriptive.moment.Variance;
import org.apache.commons.math3.stat.descriptive.summary.Sum;
import org.apache.commons.math3.stat.regression.SimpleRegression;

import static java.lang.Math.*;

/**
 * Extended math functions. Wrapper for Apache functions.
 * @author jladau
 */

public class ExtendedMath {

	/**
	 * Generates an identity matrix
	 * @param iSize Number of rows/columns
	 */
	public static double[][] matrixIdentity(int iSize){
		
		//rgd1 = output
		
		double rgd1[][];
		
		rgd1 = new double[iSize][iSize];
		for(int i=0;i<iSize;i++){
			rgd1[i][i]=1;
		}
		return rgd1;
	}
	
	/**
	 * Calculates the difference between two matrices
	 * @param rgd1 First matrix
	 * @param rgd2 Second matrix
	 * @return Difference between matrices.
	 * @throws Exception 
	 */
	public static double[][] matrixDifference(double rgd1[][], double rgd2[][]) throws Exception{
		
		//rgdOut = output
		
		double[][] rgdOut;
		
		if(rgd1.length!=rgd2.length || rgd1[0].length!=rgd2[0].length){
			throw new Exception("Matrices of different sizes.");
		}
		
		rgdOut = new double[rgd1.length][rgd1[0].length];
		for(int i=0;i<rgd1.length;i++){
			for(int j=0;j<rgd1[0].length;j++){
				rgdOut[i][j]=rgd1[i][j]-rgd2[i][j];
			}
		}
		return rgdOut;
	}
	
	/**
	 * Calculates the scalar product for a matrix
	 * @param rgd1 First matrix
	 * @param dScalar NUmber by which to multiply
	 */
	public static double[][] matrixScalarProduct(double rgd1[][], double dScalar){
		
		//rgdOut = output
		
		double[][] rgdOut;
		
		rgdOut = new double[rgd1.length][rgd1[0].length];
		for(int i=0;i<rgd1.length;i++){
			for(int j=0;j<rgd1[0].length;j++){
				rgdOut[i][j]=rgd1[i][j]*dScalar;
			}
		}
		return rgdOut;
	}
	
	/**
	 * Converts a Double array to a double array
	 * @param rgd1 Array to be converted
	 */
	public static double[][] toPrimitive(Double rgd1[][]){
		
		//rgd2 = output
		
		double rgd2[][];
		
		rgd2 = new double[rgd1.length][rgd1[0].length];
		for(int i=0;i<rgd1.length;i++){
			for(int j=0;j<rgd1[0].length;j++){
				rgd2[i][j]=rgd1[i][j];
			}
		}
		return rgd2;
	}
	
	
	/**
	 * Generates a normal random vector of iid variates
	 * @param dMean Mean
	 * @param dVariance Variance
	 * @return Random vector
	 */
	public static double[] normalRandomVector(double dMean, double dVariance, int iLength){
		
		//rgd1 = output
		//gen1 = random number generator
		//d1 = square root of variance
		
		double rgd1[];
		RandomGenerator ran1;
		double d1;
		
		d1 = Math.sqrt(dVariance);
		rgd1 = new double[iLength];
		ran1 = new JDKRandomGenerator();
		for(int i=0;i<iLength;i++){
			rgd1[i]=ran1.nextGaussian()*d1+dMean;
		}
		return rgd1;
	}
	
	/**
	 * Inverts a matrix
	 * @param rgd1 Matrix to be inverted.
	 */
	public static double[][] matrixInverse(double rgd1[][]){
		return MatrixUtils.inverse(new Array2DRowRealMatrix(rgd1)).getData();
	}
	
	/**
	 * Multiplies two matrices
	 * @param rgd1 First matrix
	 * @param rgd2 Second matrix
	 * @return Product of matrices. Error thrown if matrix dimensions don't match.
	 */
	public static double[][] matrixProduct(double rgd1[][], double rgd2[][]) throws Exception{
		
		//rgd3 = output
		
		double rgd3[][];
		
		if(rgd1[0].length!=rgd2.length){
			throw new Exception("Matrix dimensions do not match.");
		}
		rgd3 = new double[rgd1.length][rgd2[0].length];
		for(int i=0;i<rgd1.length;i++){
			for(int j=0;j<rgd2[0].length;j++){
				for(int k=0;k<rgd1[0].length;k++){
					rgd3[i][j]+=rgd1[i][k]*rgd2[k][j];
				}
			}
		}
		return rgd3;		
	}
	
	/**
	 * Multiplies two matrices, the second of which is a vector
	 * @param rgd1 First matrix
	 * @param rgd2 Second matrix
	 * @return Product of matrices. Error thrown if matrix dimensions don't match.
	 */
	public static double[] matrixProduct(double rgd1[][], double rgd2[]) throws Exception{
		
		//rgd3 = output
		
		double rgd3[];
		
		if(rgd1[0].length!=rgd2.length){
			throw new Exception("Matrix dimensions do not match.");
		}
		rgd3 = new double[rgd1.length];
		for(int i=0;i<rgd1.length;i++){
			for(int j=0;j<rgd2.length;j++){
				rgd3[i]+=rgd1[i][j]*rgd2[j];
			}
		}
		return rgd3;		
	}
	
	/**
	 * Converts ArrayList of doubles to array of doubles. 
	 * @param lst1 ArrayList to be converted.
	 * @return Array of values.
	 */
	private static double[] arrayListToDoubleArray(ArrayList<Double> lst1){
		
		//rgd1 = output
		
		double rgd1[];
		
		rgd1 = new double[lst1.size()];
		for(int i=0;i<rgd1.length;i++){
			rgd1[i]=lst1.get(i);
		}
		return rgd1;
	}
	
	
	/**
	 * Calculates slope.
	 * @param rgdX Vector of independent variables.
	 * @param rgdY Vector of dependent variables
	 * @return Slope of linear regression.
	 */
	public static double slope(double rgdX[], double rgdY[]){
		
		//srg1 = simple regression object
		
		SimpleRegression srg1;
		
		srg1 = new SimpleRegression();
		for(int i=0;i<rgdX.length;i++){
			srg1.addData(rgdX[i],rgdY[i]);
		}
		return srg1.getSlope();
	}
	
	/**
	 * Calculates Pearson correlation.
	 * @param rgdX Vector of independent variables.
	 * @param rgdY Vector of dependent variables
	 * @return Pearson correlation.
	 */
	public static double pearson(double rgdX[], double rgdY[]){	
		return (new PearsonsCorrelation()).correlation(rgdX, rgdY);
	}
	
	/**
	 * Calculates Pearson correlation.
	 * @param lstX Vector of independent variables.
	 * @param lstY Vector of dependent variables
	 * @return Pearson correlation.
	  */
	public static double pearson(ArrayList<Double> lstX, ArrayList<Double> lstY){
		return pearson(arrayListToDoubleArray(lstX),arrayListToDoubleArray(lstY));
	}
	
	/**
	 * Calculates slope.
	 * @param lstX Vector of independent variables.
	 * @param lstY Vector of dependent variables
	 * @return Slope of linear regression.
	 */
	public static double slope(ArrayList<Double> lstX, ArrayList<Double> lstY){
		
		return slope(arrayListToDoubleArray(lstX),arrayListToDoubleArray(lstY));
	}
	
	/**
	 * Calculates sum of values raised to specified power.
	 * @param rgd1 Array of double values.
	 * @return Sum.
	 */
	public static double sumOfPowers(double rgd1[], double dPower){
		
		//rgd2 = values raised to specified power
		
		double rgd2[];
		
		rgd2 = new double[rgd1.length];
		for(int i=0;i<rgd1.length;i++){
			rgd2[i]=pow(rgd1[i], dPower);
		}
		return sum(rgd2);
	}
	
	/**
	 * Calculates sum of values raised to specified power.
	 * @param rgd1 ArrayList of double values.
	 * @return Sum.
	 */
	public static double sumOfPowers(ArrayList<Double> lst1, double dPower){
		
		//rgd2 = values raised to specified power
		
		double rgd2[];
		
		rgd2 = new double[lst1.size()];
		for(int i=0;i<lst1.size();i++){
			rgd2[i]=pow(lst1.get(i), dPower);
		}
		return sum(rgd2);
	}
	
	/**
	 * Calculates sum of values centered by the mean raised to specified power.
	 * @param rgd1 ArrayList of double values.
	 * @return Sum.
	 */
	public static double sumOfPowersMeanCentered(ArrayList<Double> lst1, double dPower){
		
		//rgd2 = values raised to specified power
		//dMean = mean value
		
		double rgd2[];
		double dMean;
		
		dMean = mean(lst1);
		rgd2 = new double[lst1.size()];
		for(int i=0;i<lst1.size();i++){
			rgd2[i]=pow(lst1.get(i)-dMean, dPower);
		}
		return sum(rgd2);
	}
	
	/**
	 * Calculates sum of values centered by the mean raised to specified power.
	 * @param rgd1 Array of double values.
	 * @return Sum.
	 */
	public static double sumOfPowersMeanCentered(double rgd1[], double dPower){
		
		//rgd2 = values raised to specified power
		//dMean = mean value
		
		double dMean;
		double rgd2[];
		
		dMean = mean(rgd1);
		rgd2 = new double[rgd1.length];
		for(int i=0;i<rgd1.length;i++){
			rgd2[i]=pow(rgd1[i]-dMean, dPower);
		}
		return sum(rgd2);
	}
	
	/**
	 * Calculates arithmetic mean.
	 * @param rgd1 Array of double values.
	 * @return Arithmetic mean.
	 */
	public static double mean(double rgd1[]){
		return (new Mean()).evaluate(rgd1);
	}
	
	/**
	 * Calculates arithmetic mean.
	 * @param rgd1 ArrayList of double values.
	 * @return Arithmetic mean.
	 */
	public static double mean(ArrayList<Double> lst1){
		return (new Mean()).evaluate(arrayListToDoubleArray(lst1));
	}
	
	/**
	 * Calculates sum.
	 * @param rgd1 Array of double values.
	 * @return Sum.
	 */
	public static double sum(double rgd1[]){
		return (new Sum()).evaluate(rgd1);
	}

	/**
	 * Calculates sum.
	 * @param rgd1 ArrayList of double values.
	 * @return Sum.
	 */
	public static double sum(ArrayList<Double> lst1){
		return (new Sum()).evaluate(arrayListToDoubleArray(lst1));
	}
	
	/**
	 * Calculates population standard deviation.
	 * @param rgd1 Array of double values.
	 * @return Population standard deviation.
	 */
	public static double standardDeviationP(double rgd1[]){
		return sqrt((new Variance(false)).evaluate(rgd1));
	}
	
	/**
	 * Calculates population standard deviation.
	 * @param rgd1 ArrayList of double values.
	 * @return Population standard deviation.
	 */
	public static double standardDeviationP(ArrayList<Double> lst1){
		return sqrt((new Variance(false)).evaluate(arrayListToDoubleArray(lst1)));
	}
	
	
	
}
